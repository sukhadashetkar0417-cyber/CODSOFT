function append(value) {
    document.getElementById('display').value += value;
}

function clearDisplay() {
    document.getElementById('display').value = '';
}

function deleteChar() {
    let disp = document.getElementById('display');
    disp.value = disp.value.slice(0, -1);
}

function calculate() {
    let disp = document.getElementById('display');
    try {
        disp.value = eval(disp.value);
    } catch {
        disp.value = 'Error';
    }
}
